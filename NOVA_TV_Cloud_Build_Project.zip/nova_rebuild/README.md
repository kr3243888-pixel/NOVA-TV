# NOVA TV (starter project)

Free Android/Android TV starter player. Imports user-provided M3U playlists and plays selected HTTP(S) streams using Media3.


## Build in GitHub Actions (phone-friendly)
1. Create a public GitHub repository named `NOVA-TV`.
2. Upload **the contents of this project folder**, not the ZIP file itself. Include hidden `.github` folder.
3. Commit to the `main` branch.
4. In GitHub, open the repository's **Actions** tab. If asked, enable Actions.
5. Select **Build NOVA TV APK**, then **Run workflow** (or wait for the push build).
6. When successful, open that run and download the artifact named `NOVA-TV-debug-apk`.
7. Extract the artifact ZIP and install `app-debug.apk` on your Android device.


## Current functionality
- M3U playlist file picker
- Basic channel list with group-title display
- Media3 playback of selected HTTP/HTTPS streams
- Android phone and Android TV launcher entries
- GitHub Actions APK build workflow


## Limitations
This is an early starter project, not a polished or device-tested release. It does not provide TV channels itself. Streams must come from playlists/sources you have permission to use. M3U refresh currently means importing an updated playlist file again. EPG, automatic remote-playlist refresh, favorites, channel logos, Xtream login and robust TV remote navigation are not implemented yet.
