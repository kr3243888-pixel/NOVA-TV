package com.nova.tv

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {
    data class Channel(val name: String, val url: String, val group: String = "Live TV")
    private val channels = mutableListOf<Channel>()
    private lateinit var list: ListView
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private var player: ExoPlayer? = null
    private val pickM3u = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { loadPlaylist(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(0xFF080B14.toInt())
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,16,20,16) }
        val title = TextView(this).apply { text = "NOVA TV"; textSize = 28f; setTextColor(0xFF9B92FF.toInt()); gravity = Gravity.CENTER_VERTICAL }
        root.addView(title)
        status = TextView(this).apply { text = "Import an M3U playlist to start watching live channels."; textSize=14f; setTextColor(0xFFB8C2D8.toInt()); setPadding(0,6,0,10) }
        root.addView(status)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val importBtn = Button(this).apply { text = "Import M3U"; setOnClickListener { pickM3u.launch(arrayOf("*/*")) } }
        val refreshBtn = Button(this).apply { text = "Refresh"; setOnClickListener { status.text = "Refresh your playlist by importing an updated M3U file." } }
        row.addView(importBtn); row.addView(refreshBtn); root.addView(row)
        val content = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; layoutParams=LinearLayout.LayoutParams(-1,0,1f) }
        list = ListView(this).apply { setBackgroundColor(0xFF101827.toInt()); setOnItemClickListener { _,_,position,_ -> play(channels[position]) } }
        content.addView(list, LinearLayout.LayoutParams(0,-1,1f))
        playerView = PlayerView(this).apply { useController=true; setBackgroundColor(0xFF000000.toInt()) }
        content.addView(playerView, LinearLayout.LayoutParams(0,-1,2f))
        root.addView(content); setContentView(root)
    }
    private fun loadPlaylist(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                channels.clear(); var name = "Channel"; var group = "Live TV"
                reader.forEachLine { line ->
                    val s = line.trim()
                    if (s.startsWith("#EXTINF", true)) {
                        name = s.substringAfter(",", "Channel").trim().ifBlank { "Channel" }
                        val grp = Regex("group-title=\\\"([^\\\"]*)\\\"").find(s)
                        group = grp?.groupValues?.getOrNull(1) ?: "Live TV"
                    } else if (s.isNotEmpty() && !s.startsWith("#") && (s.startsWith("http://") || s.startsWith("https://"))) {
                        channels.add(Channel(name, s, group)); name="Channel"; group="Live TV"
                    }
                }
            }
            list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, channels.map { "${it.name}  ·  ${it.group}" })
            status.text = "Loaded ${channels.size} channels. Select a channel to play."
        } catch (e: Exception) { status.text = "Could not read playlist: ${e.localizedMessage ?: "file error"}" }
    }
    private fun play(channel: Channel) {
        try {
            if (player == null) { player = ExoPlayer.Builder(this).build(); playerView.player = player }
            player?.setMediaItem(MediaItem.fromUri(channel.url)); player?.prepare(); player?.play()
            status.text = "LIVE · ${channel.name}"
        } catch (e: Exception) { status.text = "Playback error: ${e.localizedMessage ?: "unsupported stream"}" }
    }
    override fun onDestroy() { player?.release(); player=null; super.onDestroy() }
}
