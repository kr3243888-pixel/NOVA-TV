# NOVA TV — Android / Android TV starter

Free IPTV-style player for Android phones and Android TV.

## Live catalogue behaviour
- On app launch, attempts to download the community-maintained IPTV-org public M3U catalogue (`https://iptv-org.github.io/iptv/index.m3u`).
- Includes a **Refresh Live TV** button to reload that catalogue without reinstalling the app.
- Supports importing a local M3U/M3U8 playlist through **My Playlist**.
- Channels are public/community listed and may be offline, geoblocked, or have rights restrictions. This app does not provide or unlock paid channels; check that each stream is authorized in your territory.
- This is not a guaranteed commercial channel service and channel availability is not guaranteed. Automatic refresh updates the channel list, not the underlying broadcaster's schedule or stream reliability.

## Build
1. Open this folder in Android Studio (current stable version).
2. Allow Gradle sync and install any requested Android SDK platform.
3. Build > Build APK(s).

## Targets
- Android phone/tablet
- Android TV launcher category (Leanback intent)

## Current starter limitations
- Not yet tested on physical devices or Android TV hardware.
- The TV UI has not yet been fully redesigned for D-pad focus/navigation.
- No built-in EPG provider; EPG integration remains a future feature.
- No bundled paid channel streams.
