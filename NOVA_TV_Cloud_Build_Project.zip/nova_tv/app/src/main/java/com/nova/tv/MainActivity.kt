package com.nova.tv

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL
import java.net.HttpURLConnection

private data class Channel(val name: String, val url: String, val group: String = "Channels")


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}


@Composable
private fun NovaApp() {
    val context = LocalContext.current
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var selected by remember { mutableStateOf<Channel?>(null) }
    var status by remember { mutableStateOf("Connecting to free live channel catalogue…") }
    var query by remember { mutableStateOf("") }
    var activeTab by remember { mutableStateOf("Live TV") }
    val player = remember { ExoPlayer.Builder(context).build() }
    val scope = rememberCoroutineScope()
    DisposableEffect(Unit) { onDispose { player.release() } }

    // Refresh the public catalogue on each app launch.
    LaunchedEffect(Unit) {
        try {
            val fresh = withContext(Dispatchers.IO) { fetchPublicChannels() }
            channels = fresh
            selected = fresh.firstOrNull()
            selected?.let { player.setMediaItem(MediaItem.fromUri(it.url)); player.prepare() }
            status = "Updated live catalogue • ${fresh.size} channels"
        } catch (e: Exception) {
            status = "Live catalogue unavailable. Import your own M3U playlist."
        }
    }

    fun refreshCatalogue() {
        status = "Refreshing live channels…"
        scope.launch {
            try {
                val fresh = withContext(Dispatchers.IO) { fetchPublicChannels() }
                channels = fresh
                selected = fresh.firstOrNull()
                selected?.let { player.setMediaItem(MediaItem.fromUri(it.url)); player.prepare() }
                status = "Catalogue updated • ${fresh.size} channels"
            } catch (e: Exception) {
                status = "Refresh failed. Try again or import a playlist."
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            status = "Loading playlist…"
            scope.launch {
                try {
                    val loaded = withContext(Dispatchers.IO) { readM3u(context, uri) }
                    channels = loaded
                    selected = loaded.firstOrNull()
                    selected?.let { player.setMediaItem(MediaItem.fromUri(it.url)); player.prepare() }
                    status = if (loaded.isEmpty()) "No playable entries found. Check the playlist format." else "Loaded ${loaded.size} channels"
                } catch (e: Exception) { status = "Could not read playlist: ${e.message ?: "unknown error"}" }
            }
        }
    }

    val filtered = channels.filter { it.name.contains(query, true) || it.group.contains(query, true) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF9B8CFF), background = Color(0xFF090B12), surface = Color(0xFF151824))) {
        Row(Modifier.fillMaxSize().background(Color(0xFF090B12))) {
            Column(Modifier.widthIn(min = 150.dp, max = 230.dp).fillMaxHeight().padding(18.dp)) {
                Text("NOVA", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color(0xFF9B8CFF))
                Text("TV", fontSize = 16.sp, color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(28.dp))
                listOf("Home", "Live TV", "Movies", "Series", "Favorites", "Settings").forEach { tab ->
                    Surface(color = if (activeTab == tab) Color(0xFF27243F) else Color.Transparent, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { activeTab = tab }) {
                        Text(tab, color = Color.White, modifier = Modifier.padding(14.dp), fontSize = 16.sp)
                    }
                }
                Spacer(Modifier.weight(1f))
                Button(onClick = { refreshCatalogue() }, modifier = Modifier.fillMaxWidth()) { Text("↻ Refresh Live TV") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("＋ My Playlist") }
            }
            Column(Modifier.fillMaxSize().padding(18.dp)) {
                Text("${activeTab.uppercase()}  •  FREE", color = Color(0xFFB8B5FF), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                Text("Welcome to NOVA TV", fontSize = 28.sp, color = Color.White, fontWeight = FontWeight.Bold)
                Text(status, color = Color(0xFFADB3C4), modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column(Modifier.weight(1.35f)) {
                        if (selected != null) {
                            AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp, max = 400.dp).background(Color.Black))
                            Text(selected?.name ?: "", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                        } else {
                            Box(Modifier.fillMaxWidth().height(260.dp).background(Color(0xFF151824), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                                Text("Your screen is ready 📺\nImport a playlist to begin", color = Color.LightGray)
                            }
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        OutlinedTextField(query, { query = it }, label = { Text("Search channels") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(filtered) { channel ->
                                Surface(color = if (selected == channel) Color(0xFF292641) else Color(0xFF151824), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().clickable {
                                    selected = channel
                                    player.setMediaItem(MediaItem.fromUri(channel.url)); player.prepare(); player.play()
                                }) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(channel.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                        Text(channel.group, color = Color(0xFF9EA4B6), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                Text("NOVA TV • Free live catalogue and playlist player", color = Color(0xFF747B8D), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            }
        }
    }
}


private fun fetchPublicChannels(): List<Channel> {
    val url = URL("https://iptv-org.github.io/iptv/index.m3u")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        connectTimeout = 15000
        readTimeout = 20000
        requestMethod = "GET"
        setRequestProperty("User-Agent", "NOVA-TV/1.1")
    }
    try {
        connection.inputStream.use { stream -> return parseM3u(stream) }
    } finally { connection.disconnect() }
}


private fun readM3u(context: android.content.Context, uri: Uri): List<Channel> {
    val list = mutableListOf<Channel>()
    context.contentResolver.openInputStream(uri)?.use { stream ->
        list.addAll(parseM3u(stream))
    }
    return list
}


private fun parseM3u(stream: java.io.InputStream): List<Channel> {
    val list = mutableListOf<Channel>()
    BufferedReader(InputStreamReader(stream)).use { reader ->
            var name = "Channel"
            var group = "Channels"
            var line: String?
            while (true) {
                line = reader.readLine() ?: break
                val trimmed = line.trim()
                if (trimmed.startsWith("#EXTINF", true)) {
                    name = trimmed.substringAfter(",", "Channel").trim().ifBlank { "Channel" }
                    val groupMatch = Regex("group-title=\\\"([^\\\"]+)\\\"", RegexOption.IGNORE_CASE).find(trimmed)
                    group = groupMatch?.groupValues?.get(1) ?: "Channels"
                } else if (trimmed.isNotEmpty() && !trimmed.startsWith("#") && (trimmed.startsWith("http://") || trimmed.startsWith("https://"))) {
                    list.add(Channel(name, trimmed, group))
                    name = "Channel"; group = "Channels"
                }
            }
        }
    return list
}
